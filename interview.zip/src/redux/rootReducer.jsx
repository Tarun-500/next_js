import { combineReducers } from "redux";
import { StepperReducer } from "../app/stepper/reducer.jsx";

const rootReducer = combineReducers({
  StepperReducer,
});
export default rootReducer;

