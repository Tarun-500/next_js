const uriConstant = {
    VEHICLE: "/vehicle",
    OPTIONS: "/options",
    BUYER: "/buyer",
    STEP_ONE: "/step-one",
    OTP_SERVICE: "/otp-service",
    SEND: "/send",
    BUYER_LOGIN: "/buyer-login",
    STEP_TWO: "/step-two",
    STEP_THREE: "/step-three",
    STEP_FOUR: "/step-four",
    CLIENT: "/client",
    STATE: "/state",
    CITY: "/city",
    PINCODE: "/pincode",

};
export default uriConstant;
